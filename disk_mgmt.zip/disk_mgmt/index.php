<?php
require_once("disk_details.php");
<!DOCTYPE html>
<html lang="en">
    <head>
    <style type='text/css'>

        .progress {
                border: 2px solid #5E96E4;
                height: 32px;
                width: 540px;
                margin: 30px auto;
        }
        .progress .prgbar {
                background: #A7C6FF;
                width: <?php echo $dp; ?>%;
                position: relative;
                height: 32px;
                z-index: 999;
        }
        .progress .prgtext {
                color: #286692;
                text-align: center;
                font-size: 13px;
                padding: 9px 0 0;
                width: 540px;
                position: absolute;
                z-index: 1000;
        }
        .progress .prginfo {
                margin: 3px 0;
        }
    </style>

    </head>

    <body>
    <div class='progress'>
            <div class='prgtext'><?php echo $dp; ?>% Disk Used</div>
            <div class='prgbar'></div>
            <div class='prginfo'>
                    <span style='float: left;'><?php echo "$du of $dt used"; ?></span>
                    <span style='float: right;'><?php echo "$df of $dt free"; ?></span>
                    <span style='clear: both;'></span>
            </div>
    </div>
    </body>
    </html>
?>